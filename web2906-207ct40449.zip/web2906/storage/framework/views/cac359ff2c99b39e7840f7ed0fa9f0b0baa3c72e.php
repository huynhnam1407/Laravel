<table border="0" cellpadding = "0" cellspacing = "0" 
style = "width:780px; height:147px; background-image:url(images/profileBanner.gif);">
	<tr style="height:47px;">
		<td style="width:175px;"></td>
		<td style="width:605px;" align="left" valign="bottom">
			<span style="font-size:24px; font-weight:bold; font-style:italic; color:#d57902;">
			Giới thiệu Công ty
			</span>
		</td>	
	</tr>
	<tr style="height:100px;">
		<td></td>
		<td></td>	
	</tr>
</table><?php /**PATH C:\xampp\htdocs\web2906\resources\views/header/banner.blade.php ENDPATH**/ ?>